#include <stdio.h>

int main() {
	printf("started\n");
	int counter = 0;
	while(counter == 0);
	printf("exiting..\n");
}